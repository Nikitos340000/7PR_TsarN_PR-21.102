package com.example.a7pr_tsarevnikita_pr_21102;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class contacts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
    }
}